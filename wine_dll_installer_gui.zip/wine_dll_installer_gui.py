import tkinter as tk
from tkinter import scrolledtext, messagebox
import subprocess
import threading
import time
import shutil
import re

def run_protontricks_command(app_id, dll, update_callback):
    cmd = f"{PROTONTRICKS_CMD} {app_id} --force -q {dll}"
    try:
        process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, universal_newlines=True)
        for line in process.stdout:
            update_callback(line)
        process.wait(timeout=300)  # 5分鐘超時
        return "命令執行完成\n"
    except subprocess.TimeoutExpired:
        return f"安裝 {dll} 超時，可能需要手動檢查。\n"
    except Exception as e:
        return f"執行命令時發生錯誤：{str(e)}\n"

def update_text(text):
    result_text.insert(tk.END, text)
    result_text.see(tk.END)  # 滾動到最後一行
    result_text.update()

def update_timer_and_status():
    global current_dll
    elapsed_time = time.time() - start_time
    minutes, seconds = divmod(int(elapsed_time), 60)
    status_text = f"正在安裝: {current_dll}" if installing else "等待開始"
    status_timer_label.config(text=f"{status_text} | 已用時間: {minutes:02d}:{seconds:02d}")
    if installing:
        root.after(1000, update_timer_and_status)  # 每秒更新一次

def countdown_and_close():
    global countdown, total_time
    if countdown > 0:
        minutes, seconds = divmod(int(total_time), 60)
        status_timer_label.config(text=f"程序{countdown}秒後關閉 | 已用時間: {minutes:02d}:{seconds:02d}")
        countdown -= 1
        root.after(1000, countdown_and_close)
    else:
        root.destroy()

def install_dlls_thread():
    global installing, start_time, countdown, current_dll, total_time
    app_id = app_id_entry.get()
    if not app_id.isdigit():
        update_text("錯誤：Steam App ID 必須是一個數字。\n")
        install_button.config(state=tk.NORMAL, text="安裝 DLL")
        query_button.config(state=tk.NORMAL)
        installing = False
        return

    result_text.delete(1.0, tk.END)
    update_text(f"開始為 Steam App ID {app_id} 安裝 DLL...\n")

    if option_var.get() == 1:  # Wmp11 Directshow
        dlls = ["wmp11", "directshow"]
    else:  # lavfilters quartz
        dlls = ["lavfilters", "quartz"]

    for dll in dlls:
        current_dll = dll
        update_text(f"正在安裝 {dll}...\n")
        output = run_protontricks_command(app_id, dll, update_text)
        update_text(output)

    update_text("安裝過程完成\n")
    install_button.config(state=tk.NORMAL, text="安裝 DLL")
    query_button.config(state=tk.NORMAL)
    installing = False
    total_time = time.time() - start_time
    countdown = 5
    countdown_and_close()

def install_dlls():
    global installing, start_time
    install_button.config(state=tk.DISABLED, text="安裝中")
    query_button.config(state=tk.DISABLED)
    installing = True
    start_time = time.time()
    update_timer_and_status()
    
    # 隱藏未選中的選項
    if option_var.get() == 1:
        option2.pack_forget()
    else:
        option1.pack_forget()
    
    threading.Thread(target=install_dlls_thread, daemon=True).start()

def query_steam_apps():
    def fetch_apps():
        try:
            cmd = f"{PROTONTRICKS_CMD} --list"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            apps = []
            for line in result.stdout.split('\n'):
                match = re.match(r"(.*) \((\d+)\)$", line.strip())
                if match:
                    app_name, app_id = match.groups()
                    apps.append((app_id, app_name))
            
            result_text.delete(1.0, tk.END)
            if apps:
                result_text.insert(tk.END, "APP ID\t\t遊戲名\n")
                result_text.insert(tk.END, "-" * 60 + "\n")
                for app_id, app_name in apps:
                    result_text.insert(tk.END, f"{app_id}\t\t{app_name}\n")
            else:
                result_text.insert(tk.END, "未找到任何 Steam 應用。請確保您已經通過 Steam 安裝了遊戲，並且至少運行過一次。\n")
        except Exception as e:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"獲取應用列表時出錯: {str(e)}\n")
            result_text.insert(tk.END, f"命令輸出: {result.stdout}\n")
            result_text.insert(tk.END, f"錯誤輸出: {result.stderr}\n")

    threading.Thread(target=fetch_apps, daemon=True).start()

# 創建主視窗
root = tk.Tk()
root.title("Wine DLL 安裝器")

# 檢查Protontricks的安裝方式
if shutil.which("protontricks"):
    PROTONTRICKS_CMD = "protontricks"
elif shutil.which("flatpak"):
    result = subprocess.run(["flatpak", "list", "--app"], capture_output=True, text=True)
    if "com.github.Matoking.protontricks" in result.stdout:
        PROTONTRICKS_CMD = "flatpak run com.github.Matoking.protontricks"
    else:
        messagebox.showerror("錯誤", "未找到protontricks。請先通過Discover商店或套件管理器安裝protontricks。")
        exit(1)
else:
    messagebox.showerror("錯誤", "未找到protontricks。請先通過Discover商店或套件管理器安裝protontricks。")
    exit(1)

# 創建頂部框架
top_frame = tk.Frame(root)
top_frame.pack(pady=10, padx=10, fill=tk.X)

# 第一行
first_row = tk.Frame(top_frame)
first_row.pack(fill=tk.X)

option_label = tk.Label(first_row, text="請選擇你安裝的套件：")
option_label.pack(side=tk.LEFT)

input_frame = tk.Frame(first_row)
input_frame.pack(side=tk.RIGHT)
tk.Label(input_frame, text="Steam App ID:").pack(side=tk.LEFT)
app_id_entry = tk.Entry(input_frame, width=20)
app_id_entry.pack(side=tk.LEFT, padx=5)

# 第二行
second_row = tk.Frame(top_frame)
second_row.pack(fill=tk.X, pady=(5, 0))

option_var = tk.IntVar(value=1)  # 默認選擇 Wmp11 Directshow
option1 = tk.Radiobutton(second_row, text="Wmp11 Directshow", variable=option_var, value=1)
option1.pack(side=tk.LEFT)

button_frame = tk.Frame(second_row)
button_frame.pack(side=tk.RIGHT)

install_button = tk.Button(button_frame, text="安裝 DLL", command=install_dlls)
install_button.pack(side=tk.LEFT, padx=(0, 5))

query_button = tk.Button(button_frame, text="查詢所有 App", command=query_steam_apps)
query_button.pack(side=tk.LEFT)

# 第三行
third_row = tk.Frame(top_frame)
third_row.pack(fill=tk.X)

option2 = tk.Radiobutton(third_row, text="Lavfilters Quartz", variable=option_var, value=2)
option2.pack(side=tk.LEFT)

# 創建並放置狀態和計時器標籤
status_timer_label = tk.Label(root, text="等待開始 | 已用時間: 00:00")
status_timer_label.pack(pady=5)

# 創建並放置提示標籤
tk.Label(root, text="注意：遊戲至少需要啟動過一次，才能正常安裝。", fg="red").pack(pady=5)

# 創建並放置結果顯示區域
result_text = scrolledtext.ScrolledText(root, height=20, width=80)
result_text.pack(pady=5, padx=10, expand=True, fill=tk.BOTH)

# 全局變量
installing = False
start_time = 0
countdown = 5
current_dll = ""
total_time = 0

# 運行主循環
root.mainloop()